#ifndef ARMOR_H
#define ARMOR_H



typedef struct Armor
{
    ArmorType type;
    int bonus;
}

#endif
