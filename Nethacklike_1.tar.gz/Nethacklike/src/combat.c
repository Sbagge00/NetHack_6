#include "rogue.h"

int combat(Player * player, Monster * monster, int order)
{
/*
    // player attacking
    if (order == 1)
    {
        monster->health -= player->attack;
        if (monster->health > 0)
        {
            player->health -= monster->attack;
        }
        else
        {
            killMonster(monster);
            player->exp++;
        }
    }
    // monster attacking 
    else
    {
        player->health -= monster->attack;
        if (player->health > 0)
        {
            monster->health -= player->attack;
        }
    }

    return 1;
*/

} 


int arrowTrap(Position * newPosition, Player * user, char ** level)
{
	int num;	
	srand(time(0));
  	num = rand() % 20 + user->dexMod;
	if (num >= 13)
	{    	
	mvprintw(0, 0, "You sprung a spike trap! The spikes hit you!    ");	
	user->hp -= 1;
 	mvprintw(23, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	} else {
	mvprintw(0, 0, "You sprung a spike trap! But you dodge out of the way! ");
	}
	return 1;
}

int healing(Position * newPosition, Player * user, char ** level)
{
    	if (user->hp < user->maxhp)
	{
	user->hp += 1;
 	mvprintw(23, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	} else {
	mvprintw(23, 1, "HP: %d(%d) ", user->hp, user->maxhp);
	}

	return 1;
}

int spellHealingWord(Position * newPosition, Player * user, char ** level)
{
	int num;	
	srand(time(0));
  	num = rand() % 4 + user->wisMod;
    	if (user->hp < user->maxhp)
	{
	user->hp += num;
	if (user->hp > user->maxhp)
        {
	user->hp = user->maxhp;
 	mvprintw(23, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	} else {
 	mvprintw(23, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	}
	}
	return 1;
}

int pitTrap(Position * newPosition, Player * user, char ** level)
{
	mvprintw(0, 0, "You fell down a pit!");	
        race(newPosition, user, level);
	user->hp -= 7;
 	mvprintw(23, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
 
	return 1;
}
  
