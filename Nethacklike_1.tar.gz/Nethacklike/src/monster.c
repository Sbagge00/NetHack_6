#include <rogue.h>

int addMonsters(Level * level)
{
//  int x;
//  level->monsters = malloc(sizeof(Monster *)* 6);
//  level->numberOfMonsters = 1;

//  for (x = 0; x < level->numberOfRooms; x++)
//  {
//      if ((rand() % 2) == 0)
//	{
//	   level->monsters[level->numberOfMonsters] = selectMonster(level->level);
//	   setStartingPosition(level->monsters[level->numberOfMonsters], level->rooms[x]);
//	   level->numberOfMonsters++'
//	}
//  }
    mvprintw(8, 19, "o");
}

Monster * selectMonster(int level)
{
    int monster;
    switch (level)
    {
	case 1:
	case 2:
	case 3:
	    monster = (rand() % 3) +1;
	    break;
	case 4:
	case 5:
            monster = (rand() % 3) +2;
	    break;
	case 6:
	    monster = 4;
	    break;
    }

/*
1 Giant Spider
symbol: s
HP: 2
AC: 12
ATTACK: +4 to hit  1 dmg

2 Goblin
symbol: o (white)
HP: 7
AC: 15
ATTACK: +4 to hit  1d6 + 2 dmg

3 Zombie
symbol: z (white)
HP: 22
AC: 8
ATTACK: +3 to hit  1d6 +1 dmg
when hp == 0, there is a 20% the zombie hp = 1

4 Specter
symbol: S (purple)
HP: 22
AC: 12
ATTACK: +4 to hit  8 dmg - conMod (lowers max hp)
*/
    mvprintw(0, 0, "monster: %d", monster);
    getch();

    switch (monster)
    {
	case 1: /*spider*/
	    return createMonster('s', 2, 1, 1, 12, 1);
	case 2: /*goblin*/
	    return createMonster('o', 7, 5, 1, 15, 1);
	case 3: /*zombie*/
	    return createMonster('z', 22, 4, 1, 8, 1);
	case 4: /*specter*/
	    return createMonster('S', 22, 8, 1, 12, 1);
    }

}

Monster * createMonster(char symbol, int hp, int attack, int speed, int ac, int pathfinding)
{
    Monster * newMonster;
    newMonster = malloc(sizeof(Monster));

    newMonster->symbol = symbol;
    newMonster->hp = hp;
    newMonster->attack - attack;
    newMonster->speed = speed;
    newMonster->ac = ac;
    newMonster->pathfinding = pathfinding;
    newMonster->alive = 1;

    sprintf(newMonster->string, "%c", symbol);


   return newMonster;
}

int killMonster(Monster * monster)
{
    mvprintw(monster->position->y, monster->position->x, ".");
//    newMonster->alive = 0;

    return 1;
}

int setStartingPosition(Monster * monster)
{
    monster->position->x = 20;
    monster->position->y = 8;

    mvprintw(monster->position->y, monster->position->x, monster->string);
}

int moveMonsters(Level * level)
{
    int x;
    for (x = 0; x < level->numberOfMonsters; x++)
    {
	if (level->monsters[x]->alive = 0)
	     continue;

        mvprintw(level->monsters[x]->position->y, level->monsters[x]->position->x, ".");	

	if (level->monsters[x]->pathfinding == 1)
	{
		getch();
	      // random 
	} else { 
	      pathfindingSeek(level->monsters[x]->position, level->user->position);
	}

	mvprintw(level->monsters[x]->position->y, level->monsters[x]->position->x, level->monsters[x]->string);
   }

}

int pathfindingSeek(Position * start, Position * destination)
{
/* step left */
    if ((abs((start->x - 1) - destination->x) < abs(start->x - destination->x)) && (mvinch(start->y, start->x - 1) == '.'))
    {
        start->x = start->x - 1;

    /* step right */
    } else if ((abs((start->x + 1) - destination->x) < abs(start->x - destination->x)) && (mvinch(start->y, start->x + 1) == '.'))
    {
        start->x = start->x + 1;
    
    /* step down */
    } else if ((abs((start->y + 1) - destination->y) < abs(start->y - destination->y)) && (mvinch(start->y + 1, start->x) == '.'))
    {
        start->y = start->y + 1;

    /* step up */
    } else if ((abs((start->y - 1) - destination->y) < abs(start->y - destination->y)) && (mvinch(start->y - 1, start->x) == '.'))
    {
        start->y = start->y - 1;
    } else
    {
        /* do nothing */
    }

return 1;

}

Monster * getMonsterAt(Position * position, Monster ** monsters)
{
    int x;
    for (x = 0; x < 6; x++)
    {
	if ((position->y == monsters[x]->position->y) && (position->x == monsters[x]->position->x))
	      return monsters[x];

    }

return NULL;

}





